import React from 'react'; 
import ReactDOM from 'react-dom'; 
import './index.css'; 
import reportWebVitals from './reportWebVitals';
// import * as serviceWorker from './serviceWorker'; 
import HookControlledButtonState from './StatewithHookButton'; 
import EmojeeCounter from './EmojeeCounter'; 

// ReactDOM.render( 
// <React.Fragment> 
// <HookControlledButtonState/>
// </React.Fragment>, 
// document.getElementById('root') 
// ); 


ReactDOM.render( 
  <React.StrictMode>
  <HookControlledButtonState/>
  <EmojeeCounter pic='Love'/> 
  <EmojeeCounter pic='sad'/> 
  <EmojeeCounter pic='Like'/> 
  </React.StrictMode>, 
  document.getElementById('root') );

reportWebVitals();