
exports.Perimeter=(Length, Width)=> {
return 2*(Length*Width);    
}

exports.Area=(Length, Width)=> {
    return Length*Width;    
    }