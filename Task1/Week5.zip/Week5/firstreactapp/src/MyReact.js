import './App.css'; 
import React from 'react'; 
function MyReact(props) { 
    console.log(props.heading); 
    return ( <div className="App"> <h1>{props.heading}</h1>; </div> ); } 
    
export default MyReact;